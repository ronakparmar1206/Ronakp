import React from 'react'
import './Project.css'
import web from "../src/image/images.png"
function Home() {
  
  return (
    <>
    <section className='main'>
    <div className='heading'>
    <h1>Grow your business with <br/><span>ThapaTeachnical</span></h1>
    <p>We are the team of talented</p>
    <button>Get started</button>
    </div>
    <div className='image'>
      <img src={web} alt="home img" />
      </div>

    </section>
    </>
  );
}

export default Home